# Verified Card & QR Pay

A safety-first personal finance web app that adds a deliberate verification checkpoint before card controls or UPI QR payments.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Product

- Home screen with two primary paths: Card controls and Pay by QR.
- Card controls with local sample-card lock/unlock state, browser geolocation permission, trusted-area toggle, and adjustable safety radius.
- Pay by QR with UPI ID entry, local browser QR image/camera reading, strict payee matching, mismatch blocking, and UPI deep-link handoff.
- The interface explicitly distinguishes local verification from real bank/UPI execution; no card details or payment history are stored.

## User preferences

_None recorded._

## Gotchas

- The QR reader uses the browser's `BarcodeDetector` API. Unsupported browsers show a clear not-found state rather than accepting unverified data.
- Selecting Pay opens the user's installed UPI app; this website does not claim transaction success or move money itself.
- The card controls are intentionally local demo controls and do not contact a bank processor.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
