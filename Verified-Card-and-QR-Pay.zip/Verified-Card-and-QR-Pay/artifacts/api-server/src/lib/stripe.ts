import { ReplitConnectors } from "@replit/connectors-sdk";

const connectors = new ReplitConnectors();

export async function stripeRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const response = await connectors.proxy("stripe", path, {
    ...init,
    headers: {
      accept: "application/json",
      ...(init.body ? { "content-type": "application/x-www-form-urlencoded" } : {}),
      ...init.headers,
    },
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Stripe request failed (${response.status}): ${body.slice(0, 500)}`);
  }

  return (await response.json()) as T;
}

export function stripeForm(values: Record<string, string | undefined>) {
  const form = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== undefined) form.set(key, value);
  }
  return form.toString();
}