import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { db } from "@workspace/db";
import { userSessions } from "@workspace/db";
import { eq } from "drizzle-orm";

const COOKIE_NAME = "verified_session";
const SESSION_MAX_AGE = 1000 * 60 * 60 * 24 * 30;

function secret() {
  return process.env.SESSION_SECRET || "development-only-session-secret";
}

function sign(value: string) {
  return createHmac("sha256", secret()).update(value).digest("hex");
}

function encode(value: string) {
  return `${value}.${sign(value)}`;
}

function decode(value: string | undefined) {
  if (!value) return null;
  const [sessionId, signature] = value.split(".");
  if (!sessionId || !signature || signature.length !== 64) return null;

  const expected = Buffer.from(sign(sessionId), "hex");
  const actual = Buffer.from(signature, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected)
    ? sessionId
    : null;
}

export async function getSessionId(req: Request, res: Response) {
  const existing = decode(req.cookies?.[COOKIE_NAME]);
  const sessionId = existing || randomUUID();

  if (!existing) {
    res.cookie(COOKIE_NAME, encode(sessionId), {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: SESSION_MAX_AGE,
      path: "/",
    });
  }

  await db
    .insert(userSessions)
    .values({ id: sessionId })
    .onConflictDoNothing({ target: userSessions.id });

  return sessionId;
}

export async function getSession(sessionId: string) {
  return db.query.userSessions.findFirst({
    where: eq(userSessions.id, sessionId),
  });
}