import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import {
  CheckLocationBody,
  CheckLocationResponse,
  VerifyLocationOtpBody,
} from "@workspace/api-zod";
import { db, locationChallenges, locationEvents } from "@workspace/db";
import { getSession, getSessionId } from "../lib/session";

const TRUSTED_RADIUS_KM = 5;
const CHALLENGE_TTL_MS = 10 * 60 * 1000;
const router: IRouter = Router();

function distanceKm(
  latitudeA: number,
  longitudeA: number,
  latitudeB: number,
  longitudeB: number,
) {
  const earthRadiusKm = 6371;
  const toRadians = (value: number) => (value * Math.PI) / 180;
  const deltaLatitude = toRadians(latitudeB - latitudeA);
  const deltaLongitude = toRadians(longitudeB - longitudeA);
  const a =
    Math.sin(deltaLatitude / 2) ** 2 +
    Math.cos(toRadians(latitudeA)) *
      Math.cos(toRadians(latitudeB)) *
      Math.sin(deltaLongitude / 2) ** 2;
  return 2 * earthRadiusKm * Math.asin(Math.sqrt(a));
}

router.post("/location/check", async (req, res) => {
  const parsed = CheckLocationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "invalid_location",
      message: "A valid latitude and longitude are required.",
    });
    return;
  }

  const sessionId = await getSessionId(req, res);
  const previous = await db.query.locationEvents.findFirst({
    where: eq(locationEvents.sessionId, sessionId),
    orderBy: [desc(locationEvents.createdAt)],
  });
  const { latitude, longitude, accuracyMeters } = parsed.data;
  const distance = previous
    ? distanceKm(previous.latitude, previous.longitude, latitude, longitude)
    : null;
  const status = !previous
    ? "baseline"
    : distance !== null && distance > TRUSTED_RADIUS_KM
      ? "requires_confirmation"
      : "trusted";
  const eventId = randomUUID();

  await db.insert(locationEvents).values({
    id: eventId,
    sessionId,
    latitude,
    longitude,
    accuracyMeters: accuracyMeters ?? null,
    previousLatitude: previous?.latitude ?? null,
    previousLongitude: previous?.longitude ?? null,
    distanceKm: distance,
    status,
  });

  let challengeId: string | null = null;
  if (status === "requires_confirmation") {
    challengeId = randomUUID();
    await db.insert(locationChallenges).values({
      id: challengeId,
      sessionId,
      locationEventId: eventId,
      status: "pending",
      channel: "sms",
      maskedDestination: (await getSession(sessionId))?.phoneE164
        ? "ending in " + (await getSession(sessionId))?.phoneE164?.slice(-4)
        : null,
      expiresAt: new Date(Date.now() + CHALLENGE_TTL_MS),
    });
  }

  const message =
    status === "baseline"
      ? "This location is now the starting point for movement checks."
      : status === "trusted"
        ? "The current location is within the trusted radius."
        : "A move outside the trusted radius needs confirmation before card use can continue.";

  res.json(
    CheckLocationResponse.parse({
      eventId,
      status,
      distanceKm: distance,
      trustedRadiusKm: TRUSTED_RADIUS_KM,
      challengeId,
      message,
    }),
  );
});

router.post("/location-challenges/:challengeId/request-otp", async (req, res) => {
  const sessionId = await getSessionId(req, res);
  const challenge = await db.query.locationChallenges.findFirst({
    where: and(
      eq(locationChallenges.id, req.params.challengeId),
      eq(locationChallenges.sessionId, sessionId),
    ),
  });
  if (!challenge) {
    res.status(404).json({
      error: "challenge_not_found",
      message: "This location confirmation is no longer available.",
    });
    return;
  }

  await db
    .update(locationChallenges)
    .set({ status: "otp_unavailable" })
    .where(eq(locationChallenges.id, challenge.id));

  res.status(503).json({
    error: "otp_provider_not_configured",
    message:
      "The SMS provider is not connected, so no OTP was sent. Connect Twilio before enabling bank confirmation.",
  });
});

router.post("/location-challenges/:challengeId/verify", async (req, res) => {
  const parsed = VerifyLocationOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "invalid_otp",
      message: "Enter the OTP exactly as received.",
    });
    return;
  }

  const sessionId = await getSessionId(req, res);
  const challenge = await db.query.locationChallenges.findFirst({
    where: and(
      eq(locationChallenges.id, req.params.challengeId),
      eq(locationChallenges.sessionId, sessionId),
    ),
  });
  if (!challenge) {
    res.status(400).json({
      error: "challenge_not_found",
      message: "This location confirmation is no longer available.",
    });
    return;
  }

  res.status(503).json({
    error: "otp_provider_not_configured",
    message:
      "OTP verification is disabled until an SMS/bank confirmation provider is connected.",
  });
});

export default router;