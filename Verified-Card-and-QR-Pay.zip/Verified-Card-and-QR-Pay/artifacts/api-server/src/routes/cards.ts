import { Router, type IRouter } from "express";
import { randomUUID } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import {
  CompleteCardSetupSessionBody,
  CreateCardSetupSessionResponse,
  ListCardsResponse,
  CompleteCardSetupSessionResponse,
} from "@workspace/api-zod";
import { db, cardProfiles, userSessions } from "@workspace/db";
import { getSession, getSessionId } from "../lib/session";
import { stripeForm, stripeRequest } from "../lib/stripe";

type StripeCustomer = { id: string };
type StripeCheckoutSession = {
  id: string;
  url: string | null;
  status: string | null;
  setup_intent: string | { id: string; status: string; payment_method: string | null } | null;
  customer_details?: { phone?: string | null } | null;
};
type StripePaymentMethod = {
  id: string;
  type: string;
  card?: {
    brand?: string;
    last4?: string;
    exp_month?: number;
    exp_year?: number;
  };
  billing_details?: { name?: string | null };
};

const router: IRouter = Router();

function publicOrigin(req: Parameters<IRouter["post"]>[1] extends never ? never : any) {
  const protocol = req.get("x-forwarded-proto") || req.protocol;
  const host = req.get("x-forwarded-host") || req.get("host");
  return `${protocol}://${host}`;
}

router.get("/cards", async (req, res) => {
  const sessionId = await getSessionId(req, res);
  const rows = await db.query.cardProfiles.findMany({
    where: eq(cardProfiles.sessionId, sessionId),
    orderBy: [desc(cardProfiles.createdAt)],
  });
  res.json(ListCardsResponse.parse(rows));
});

router.post("/cards/setup-session", async (req, res) => {
  const sessionId = await getSessionId(req, res);
  try {
    let session = await getSession(sessionId);
    let customerId = session?.stripeCustomerId;

    if (!customerId) {
      const customer = await stripeRequest<StripeCustomer>("/v1/customers", {
        method: "POST",
        body: stripeForm({
          description: "Verified Card & QR Pay customer",
          "metadata[verified_session_id]": sessionId,
        }),
      });
      customerId = customer.id;
      await db
        .update(userSessions)
        .set({ stripeCustomerId: customerId })
        .where(eq(userSessions.id, sessionId));
    }

    const origin = publicOrigin(req);
    const checkout = await stripeRequest<StripeCheckoutSession>("/v1/checkout/sessions", {
      method: "POST",
      body: stripeForm({
        mode: "setup",
        customer: customerId,
        "payment_method_types[0]": "card",
        "phone_number_collection[enabled]": "true",
        success_url: `${origin}/?card_setup=success&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${origin}/?card_setup=cancelled`,
        client_reference_id: sessionId,
        "metadata[verified_session_id]": sessionId,
      }),
    });

    if (!checkout.url) {
      throw new Error("Stripe did not return a hosted setup URL.");
    }

    res.status(201).json(
      CreateCardSetupSessionResponse.parse({
        sessionId: checkout.id,
        url: checkout.url,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Unable to create Stripe card setup session");
    res.status(502).json({
      error: "stripe_setup_failed",
      message: "The bank card setup page could not be created. Please try again.",
    });
  }
});

router.post("/cards/setup-session/complete", async (req, res) => {
  const sessionId = await getSessionId(req, res);
  const parsed = CompleteCardSetupSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "invalid_setup_session",
      message: "A Stripe setup session ID is required.",
    });
    return;
  }

  try {
    const checkout = await stripeRequest<StripeCheckoutSession>(
      `/v1/checkout/sessions/${encodeURIComponent(parsed.data.sessionId)}?expand[]=setup_intent`,
    );
    if (checkout.status !== "complete" || !checkout.setup_intent) {
      res.status(400).json({
        error: "setup_incomplete",
        message: "The card setup was not completed in Stripe.",
      });
      return;
    }

    const setupIntent =
      typeof checkout.setup_intent === "string"
        ? await stripeRequest<{ id: string; status: string; payment_method: string | null }>(
            `/v1/setup_intents/${encodeURIComponent(checkout.setup_intent)}`,
          )
        : checkout.setup_intent;

    if (setupIntent.status !== "succeeded" || !setupIntent.payment_method) {
      res.status(400).json({
        error: "setup_not_verified",
        message: "Stripe has not verified this card setup yet.",
      });
      return;
    }

    const paymentMethod = await stripeRequest<StripePaymentMethod>(
      `/v1/payment_methods/${encodeURIComponent(setupIntent.payment_method)}`,
    );
    const card = paymentMethod.card;
    if (paymentMethod.type !== "card" || !card?.last4 || !card.brand || !card.exp_month || !card.exp_year) {
      res.status(400).json({
        error: "unsupported_payment_method",
        message: "The completed setup did not return a supported card.",
      });
      return;
    }

    const customerId = (await getSession(sessionId))?.stripeCustomerId;
    if (!customerId) {
      res.status(400).json({
        error: "missing_customer",
        message: "The card setup is not linked to this browser session.",
      });
      return;
    }

    const existing = await db.query.cardProfiles.findFirst({
      where: and(
        eq(cardProfiles.sessionId, sessionId),
        eq(cardProfiles.stripePaymentMethodId, paymentMethod.id),
      ),
    });
    const cardValues = {
      sessionId,
      stripeCustomerId: customerId,
      stripePaymentMethodId: paymentMethod.id,
      brand: card.brand,
      last4: card.last4,
      expMonth: card.exp_month,
      expYear: card.exp_year,
      cardholderName: paymentMethod.billing_details?.name || null,
      status: "active",
    };

    if (existing) {
      await db.update(cardProfiles).set(cardValues).where(eq(cardProfiles.id, existing.id));
    } else {
      await db.insert(cardProfiles).values({ id: randomUUID(), ...cardValues });
    }

    const phone = checkout.customer_details?.phone;
    if (phone) {
      await db
        .update(userSessions)
        .set({ phoneE164: phone })
        .where(eq(userSessions.id, sessionId));
    }

    const saved = await db.query.cardProfiles.findFirst({
      where: and(
        eq(cardProfiles.sessionId, sessionId),
        eq(cardProfiles.stripePaymentMethodId, paymentMethod.id),
      ),
    });
    res.status(201).json(CompleteCardSetupSessionResponse.parse(saved));
  } catch (error) {
    req.log.error({ err: error }, "Unable to complete Stripe card setup session");
    res.status(502).json({
      error: "stripe_setup_failed",
      message: "The completed card setup could not be verified. Please try again.",
    });
  }
});

export default router;