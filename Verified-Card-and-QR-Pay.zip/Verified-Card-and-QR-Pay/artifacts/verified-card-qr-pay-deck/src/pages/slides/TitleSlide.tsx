const base = import.meta.env.BASE_URL;

export default function TitleSlide() {
  return (
    <div className="deck-frame-dark relative h-screen w-screen overflow-hidden">
      <div className="absolute inset-y-0 right-0 w-[54vw] overflow-hidden">
        <img
          src={`${base}verified-app.jpg`}
          crossOrigin="anonymous"
          alt="Verified Card & QR Pay app preview"
          className="h-full w-full object-cover opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#18243b] via-[#18243b]/35 to-transparent" />
      </div>
      <div className="absolute -right-[8vw] -top-[18vh] h-[55vw] w-[55vw] rounded-full border-[0.1vw] border-[#74b49d]/30" />
      <div className="absolute -right-[4vw] -top-[14vh] h-[47vw] w-[47vw] rounded-full border-[0.1vw] border-[#74b49d]/20" />
      <div className="relative z-10 flex h-full w-[58vw] flex-col justify-between px-[7vw] py-[7vh]">
        <div className="flex items-center gap-[1vw]">
          <div className="flex h-[3.5vw] w-[3.5vw] items-center justify-center rounded-[0.8vw] bg-[#74b49d] text-[#18243b]">
            <span className="display text-[1.7vw] font-bold">V</span>
          </div>
          <div className="body-copy text-[1.35vw] font-bold tracking-[0.08em] text-[#fbf8f2]">VERIFIED</div>
        </div>
        <div className="max-w-[48vw]">
          <div className="deck-kicker mb-[3vh]">Product overview / safety desk</div>
          <div className="deck-rule mb-[3vh]" />
          <h1 className="display text-[6.3vw] font-semibold leading-[0.98] tracking-[-0.06em] text-[#fbf8f2]">
            Verified Card &amp; QR Pay
          </h1>
          <p className="body-copy mt-[4vh] max-w-[35vw] text-[2.2vw] leading-[1.2] text-[#fbf8f2]/78">
            Pause before money moves.
          </p>
          <p className="body-copy mt-[1.8vh] max-w-[38vw] text-[1.6vw] leading-[1.35] text-[#fbf8f2]/58">
            A safety-first web experience for unusual financial activity.
          </p>
        </div>
        <div className="flex items-end justify-between">
          <div className="tiny-mono text-[#74b49d]">01 / 08</div>
          <div className="body-copy text-[1.2vw] text-[#fbf8f2]/50">Verification before execution</div>
        </div>
      </div>
    </div>
  );
}