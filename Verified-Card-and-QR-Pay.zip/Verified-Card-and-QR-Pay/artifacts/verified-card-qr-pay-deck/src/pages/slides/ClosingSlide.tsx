export default function ClosingSlide() {
  return (
    <div className="deck-frame-dark relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#fbf8f2]/50">08 / 08</div>
      <div className="absolute -bottom-[22vw] -left-[9vw] h-[52vw] w-[52vw] rounded-full border-[0.1vw] border-[#74b49d]/30" />
      <div className="relative z-10 flex h-full flex-col justify-between">
        <div>
          <div className="deck-kicker">The intended outcome</div>
          <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
          <h1 className="display max-w-[76vw] text-[5vw] font-semibold leading-[0.98] tracking-[-0.06em] text-[#fbf8f2]">A calmer path through unusual activity</h1>
        </div>
        <div className="grid grid-cols-[1.1fr_0.9fr] gap-[7vw]">
          <div className="space-y-[2.5vh]">
            <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.15] text-[#fbf8f2]/85">Start with the issue that needs attention</p></div>
            <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.15] text-[#fbf8f2]/85">Add context before acting</p></div>
            <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.15] text-[#fbf8f2]/85">Verify the payee with two independent inputs</p></div>
            <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.15] text-[#fbf8f2]/85">Keep irreversible actions outside the safety desk</p></div>
            <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.15] text-[#fbf8f2]/85">Verified Card &amp; QR Pay turns uncertainty into a deliberate pause</p></div>
          </div>
          <div className="flex items-end justify-end">
            <div className="max-w-[24vw] border-l-[0.2vw] border-[#e97965] pl-[2vw]">
              <div className="display text-[2.5vw] font-semibold leading-[1.05] text-[#fbf8f2]">Pause.</div>
              <div className="display mt-[0.8vh] text-[2.5vw] font-semibold leading-[1.05] text-[#e97965]">Verify.</div>
              <div className="display mt-[0.8vh] text-[2.5vw] font-semibold leading-[1.05] text-[#74b49d]">Then act.</div>
            </div>
          </div>
        </div>
        <div className="flex items-end justify-between">
          <div className="tiny-mono text-[#74b49d]">Verified Card &amp; QR Pay</div>
          <div className="body-copy text-[1.2vw] text-[#fbf8f2]/50">A safety checkpoint, not a payment processor</div>
        </div>
      </div>
    </div>
  );
}