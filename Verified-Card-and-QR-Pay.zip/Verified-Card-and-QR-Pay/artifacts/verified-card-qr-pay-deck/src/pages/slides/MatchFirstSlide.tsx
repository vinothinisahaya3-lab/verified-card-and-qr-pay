export default function MatchFirstSlide() {
  return (
    <div className="deck-frame-dark relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#fbf8f2]/50">06 / 08</div>
      <div className="deck-kicker">The irreversible action gate</div>
      <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
      <h1 className="display max-w-[58vw] text-[5vw] font-semibold leading-[0.98] tracking-[-0.06em] text-[#fbf8f2]">Match first. Pay second.</h1>
      <div className="mt-[7vh] grid grid-cols-[1fr_auto_1fr] items-center gap-[2vw]">
        <div className="rounded-[1.5vw] border-[0.1vw] border-[#fbf8f2]/20 bg-[#fbf8f2]/7 p-[2.3vw]">
          <div className="tiny-mono text-[#74b49d]">entered by user</div>
          <div className="display mt-[2.5vh] text-[2.8vw] font-semibold text-[#fbf8f2]">name@bank</div>
        </div>
        <div className="flex h-[5vw] w-[5vw] items-center justify-center rounded-full bg-[#74b49d] text-[#18243b]">
          <span className="display text-[2.8vw] font-semibold">=</span>
        </div>
        <div className="rounded-[1.5vw] border-[0.1vw] border-[#fbf8f2]/20 bg-[#fbf8f2]/7 p-[2.3vw]">
          <div className="tiny-mono text-[#e97965]">decoded from QR</div>
          <div className="display mt-[2.5vh] text-[2.8vw] font-semibold text-[#fbf8f2]">name@bank</div>
        </div>
      </div>
      <div className="absolute bottom-[8vh] left-[7vw] right-[7vw] grid grid-cols-2 gap-x-[7vw] gap-y-[2.5vh]">
        <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.8vw] leading-[1.15] text-[#fbf8f2]/82">The entered UPI ID must exactly match the QR payee</p></div>
        <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.8vw] leading-[1.15] text-[#fbf8f2]/82">Malformed or unreadable codes show Not found / Mismatch</p></div>
        <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.8vw] leading-[1.15] text-[#fbf8f2]/82">A mismatch keeps payment disabled</p></div>
        <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.8vw] leading-[1.15] text-[#fbf8f2]/82">Only a verified match can open the user&apos;s UPI app</p></div>
      </div>
    </div>
  );
}