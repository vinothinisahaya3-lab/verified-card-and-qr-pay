export default function QrVerificationSlide() {
  return (
    <div className="deck-frame relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#657184]">05 / 08</div>
      <div className="deck-kicker">02 / pay by QR</div>
      <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
      <h1 className="display max-w-[64vw] text-[4.2vw] font-semibold leading-[1.02] tracking-[-0.05em]">QR payment verification</h1>
      <div className="mt-[6vh] grid grid-cols-[1.1fr_0.9fr] gap-[7vw]">
        <div className="space-y-[3vh]">
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[2vw] leading-[1.18]">Enter the payee&apos;s UPI ID yourself</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[2vw] leading-[1.18]">Upload a QR image or use the camera</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[2vw] leading-[1.18]">Decode the UPI payment payload locally in the browser</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[2vw] leading-[1.18]">Show the payee, amount, and note before handoff</p></div>
        </div>
        <div className="relative flex items-center justify-center">
          <div className="soft-card relative h-[31vw] w-[24vw] rotate-[4deg] p-[2vw]">
            <div className="tiny-mono text-[#657184]">scan locally</div>
            <div className="absolute left-[4vw] top-[8vh] grid h-[12vw] w-[12vw] grid-cols-5 gap-[0.45vw]">
              <span className="bg-[#18243b]" /><span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" /><span className="bg-[#18243b]" />
              <span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" /><span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" />
              <span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" /><span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" />
              <span className="bg-[#18243b]" /><span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" /><span className="bg-[#18243b]" />
              <span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" /><span className="bg-[#18243b]" /><span className="bg-[#18243b]" /><span className="bg-[#fbf8f2]" />
            </div>
            <div className="absolute bottom-[3vw] left-[2vw] right-[2vw] border-t-[0.1vw] border-[#18243b]/15 pt-[1.2vw]">
              <div className="tiny-mono text-[#657184]">payee details</div>
              <div className="mt-[1.2vh] h-[0.8vw] w-[11vw] rounded-full bg-[#74b49d]" />
              <div className="mt-[1vh] h-[0.8vw] w-[8vw] rounded-full bg-[#18243b]/18" />
            </div>
          </div>
          <div className="absolute bottom-[5vh] right-[1vw] h-[7vw] w-[7vw] rounded-full bg-[#e97965] p-[1.4vw] text-center">
            <div className="display pt-[0.8vw] text-[1.9vw] font-semibold">01</div>
            <div className="tiny-mono mt-[0.4vw] text-[#18243b]">read</div>
          </div>
        </div>
      </div>
    </div>
  );
}