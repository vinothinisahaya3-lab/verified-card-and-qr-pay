export default function TwoChecksSlide() {
  return (
    <div className="deck-frame relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#657184]">03 / 08</div>
      <div className="deck-kicker">The product surface</div>
      <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
      <h1 className="display max-w-[70vw] text-[4.3vw] font-semibold leading-[1.02] tracking-[-0.05em]">
        One safety desk, two deliberate checks
      </h1>
      <div className="mt-[7vh] grid grid-cols-2 gap-[2vw]">
        <div className="sage-card relative min-h-[29vh] p-[3vw]">
          <div className="flex h-[4vw] w-[4vw] items-center justify-center rounded-[1vw] bg-[#74b49d] text-[#18243b]">
            <span className="display text-[2.3vw] font-bold">01</span>
          </div>
          <h2 className="display mt-[4vh] text-[3.1vw] font-semibold tracking-[-0.04em]">Card controls</h2>
          <div className="mt-[3vh] h-[0.2vw] w-[5vw] bg-[#18243b]/55" />
        </div>
        <div className="coral-card relative min-h-[29vh] p-[3vw]">
          <div className="flex h-[4vw] w-[4vw] items-center justify-center rounded-[1vw] bg-[#e97965] text-[#18243b]">
            <span className="display text-[2.3vw] font-bold">02</span>
          </div>
          <h2 className="display mt-[4vh] text-[3.1vw] font-semibold tracking-[-0.04em]">Pay by QR</h2>
          <div className="mt-[3vh] h-[0.2vw] w-[5vw] bg-[#e97965]" />
        </div>
      </div>
      <div className="absolute bottom-[10vh] left-[7vw] right-[7vw] flex items-center justify-between border-t-[0.1vw] border-[#18243b]/15 pt-[2.8vh]">
        <p className="body-copy max-w-[48vw] text-[1.8vw] leading-[1.22]">A clear checkpoint before anything irreversible happens</p>
        <p className="body-copy max-w-[30vw] text-right text-[1.35vw] leading-[1.25] text-[#657184]">Verification happens here; the bank or UPI app completes the transaction</p>
      </div>
    </div>
  );
}