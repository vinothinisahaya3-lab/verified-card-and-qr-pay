export default function ProblemSlide() {
  return (
    <div className="deck-frame relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#657184]">02 / 08</div>
      <div className="relative z-10 max-w-[72vw]">
        <div className="deck-kicker">The context gap</div>
        <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
        <h1 className="display max-w-[62vw] text-[4.3vw] font-semibold leading-[1.03] tracking-[-0.05em]">
          The suspicious transaction problem
        </h1>
        <p className="body-copy mt-[2.5vh] max-w-[52vw] text-[1.65vw] leading-[1.35] text-[#657184]">
          The same signal can point to a harmless change or a serious risk.
        </p>
      </div>
      <div className="absolute bottom-[9vh] left-[7vw] right-[7vw] grid grid-cols-2 gap-x-[7vw] gap-y-[3.6vh]">
        <div className="bullet-row">
          <span className="bullet-dot" />
          <p className="body-copy text-[2.05vw] leading-[1.18]">Legitimate and problematic activity can look similar</p>
        </div>
        <div className="bullet-row">
          <span className="bullet-dot" />
          <p className="body-copy text-[2.05vw] leading-[1.18]">Travel, new merchants, shared accounts, and recurring services change the context</p>
        </div>
        <div className="bullet-row">
          <span className="bullet-dot" />
          <p className="body-copy text-[2.05vw] leading-[1.18]">Ignoring unusual activity can carry serious consequences</p>
        </div>
        <div className="bullet-row">
          <span className="bullet-dot" />
          <p className="body-copy text-[2.05vw] leading-[1.18]">Frequent transactions make manual review harder over time</p>
        </div>
      </div>
      <div className="absolute -bottom-[19vw] -right-[10vw] h-[42vw] w-[42vw] rounded-full border-[0.12vw] border-[#74b49d]/35" />
      <div className="absolute bottom-[7vh] right-[7vw] h-[10vw] w-[18vw] rounded-[1.4vw] border-[0.1vw] border-[#18243b]/12 bg-[#fbf8f2]/45 p-[1.4vw]">
        <div className="tiny-mono text-[#657184]">many explanations</div>
        <div className="mt-[1.8vh] flex gap-[0.65vw]">
          <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#74b49d]" />
          <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#e97965]" />
          <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#18243b]/70" />
          <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#657184]/45" />
        </div>
      </div>
    </div>
  );
}