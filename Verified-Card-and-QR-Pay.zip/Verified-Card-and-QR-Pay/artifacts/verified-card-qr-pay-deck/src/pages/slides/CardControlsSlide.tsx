export default function CardControlsSlide() {
  return (
    <div className="deck-frame relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#657184]">04 / 08</div>
      <div className="deck-kicker">01 / card controls</div>
      <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
      <h1 className="display max-w-[64vw] text-[4.2vw] font-semibold leading-[1.02] tracking-[-0.05em]">Card controls with location context</h1>
      <div className="mt-[6vh] grid grid-cols-[0.9fr_1.1fr] gap-[7vw]">
        <div className="space-y-[2.8vh]">
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.18]">Lock or unlock sample cards instantly</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.18]">Request browser location to add context</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.18]">Set a trusted-area radius</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.18]">Keep a visible pause when activity feels off</p></div>
          <div className="bullet-row"><span className="bullet-dot" /><p className="body-copy text-[1.9vw] leading-[1.18]">Location is a safety signal, not a guarantee</p></div>
        </div>
        <div className="relative min-h-[42vh]">
          <div className="absolute left-[10vw] top-[5vh] h-[26vw] w-[26vw] rounded-full border-[0.1vw] border-[#74b49d]/55" />
          <div className="absolute left-[13.2vw] top-[8.2vh] h-[19.6vw] w-[19.6vw] rounded-full border-[0.1vw] border-[#74b49d]/35" />
          <div className="absolute left-[22.6vw] top-[17.7vh] h-[0.9vw] w-[0.9vw] rounded-full bg-[#e97965]" />
          <div className="soft-card absolute left-0 top-[11vh] w-[18vw] p-[1.8vw]">
            <div className="tiny-mono text-[#657184]">card state</div>
            <div className="mt-[2vh] flex items-center justify-between">
              <span className="display text-[2.2vw] font-semibold">Locked</span>
              <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#e97965]" />
            </div>
          </div>
          <div className="sage-card absolute right-0 top-[28vh] w-[20vw] p-[1.8vw]">
            <div className="tiny-mono text-[#657184]">trusted area</div>
            <div className="mt-[2vh] flex items-center justify-between">
              <span className="display text-[2.2vw] font-semibold">5 km</span>
              <span className="h-[1.2vw] w-[1.2vw] rounded-full bg-[#2c9b72]" />
            </div>
          </div>
          <div className="absolute left-[19.8vw] top-[17vh] h-[4vw] w-[4vw] rounded-full bg-[#18243b] text-center text-[#fbf8f2]">
            <div className="display pt-[1.1vw] text-[1.5vw] font-semibold">+</div>
          </div>
        </div>
      </div>
    </div>
  );
}