export default function GuardrailsSlide() {
  return (
    <div className="deck-frame relative h-screen w-screen overflow-hidden px-[7vw] py-[7vh]">
      <div className="absolute right-[7vw] top-[7vh] tiny-mono text-[#657184]">07 / 08</div>
      <div className="deck-kicker">The boundary matters</div>
      <div className="deck-rule mt-[2.5vh] mb-[3vh]" />
      <h1 className="display max-w-[67vw] text-[4.2vw] font-semibold leading-[1.02] tracking-[-0.05em]">Designed to prevent false confidence</h1>
      <div className="mt-[7vh] grid grid-cols-2 gap-[1.6vw]">
        <div className="soft-card flex min-h-[21vh] flex-col justify-between p-[2.3vw]">
          <div className="tiny-mono text-[#e97965]">01 / block</div>
          <p className="body-copy max-w-[25vw] text-[2.05vw] leading-[1.15]">No random payment from an unverified QR</p>
        </div>
        <div className="soft-card flex min-h-[21vh] flex-col justify-between p-[2.3vw]">
          <div className="tiny-mono text-[#e97965]">02 / disclose</div>
          <p className="body-copy max-w-[25vw] text-[2.05vw] leading-[1.15]">No fake transaction success state</p>
        </div>
        <div className="soft-card flex min-h-[21vh] flex-col justify-between p-[2.3vw]">
          <div className="tiny-mono text-[#74b49d]">03 / protect</div>
          <p className="body-copy max-w-[25vw] text-[2.05vw] leading-[1.15]">No card details or payment history stored</p>
        </div>
        <div className="soft-card flex min-h-[21vh] flex-col justify-between p-[2.3vw]">
          <div className="tiny-mono text-[#74b49d]">04 / hand off</div>
          <p className="body-copy max-w-[25vw] text-[2.05vw] leading-[1.15]">Clear disclosure that the UPI app completes and reports the transaction</p>
        </div>
      </div>
      <div className="absolute bottom-[7vh] right-[7vw] h-[4vw] w-[4vw] rounded-full border-[0.2vw] border-[#74b49d]" />
      <div className="absolute bottom-[8.3vh] right-[8.3vw] h-[1.4vw] w-[1.4vw] rounded-full bg-[#74b49d]" />
    </div>
  );
}