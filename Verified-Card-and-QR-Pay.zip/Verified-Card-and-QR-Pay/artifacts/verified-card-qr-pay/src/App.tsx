import { type ChangeEvent, type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  getListCardsQueryKey,
  useCheckLocation,
  useCompleteCardSetupSession,
  useCreateCardSetupSession,
  useListCards,
  useRequestLocationOtp,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  CircleAlert,
  CreditCard,
  Crosshair,
  FileImage,
  Info,
  Landmark,
  Lock,
  MapPin,
  QrCode,
  ScanLine,
  ShieldCheck,
  Smartphone,
  Upload,
  Unlock,
  UserRound,
  WalletCards,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type View = 'home' | 'cards' | 'qr';
type CardRecord = { id: string; name: string; lastFour: string; type: string; locked: boolean; expMonth?: number; expYear?: number };
type LocationState = {
  status: 'idle' | 'loading' | 'ready' | 'error' | 'confirmation';
  label: string;
  detail: string;
  challengeId?: string | null;
};
type Payee = { pa: string; name: string; amount?: string; note?: string; raw: string };

function parseUpiPayload(payload: string): Payee | null {
  try {
    const trimmed = payload.trim();
    if (!trimmed.toLowerCase().startsWith('upi://pay')) return null;
    const url = new URL(trimmed);
    const pa = (url.searchParams.get('pa') || '').trim();
    if (!pa || !/^[a-z0-9][a-z0-9._-]{1,254}@[a-z][a-z0-9.-]{1,63}$/i.test(pa)) return null;
    return {
      pa,
      name: url.searchParams.get('pn')?.trim() || 'Unnamed payee',
      amount: url.searchParams.get('am')?.trim() || undefined,
      note: url.searchParams.get('tn')?.trim() || undefined,
      raw: trimmed,
    };
  } catch {
    return null;
  }
}

function buildPaymentLink(payee: Payee) {
  const params = new URLSearchParams({ pa: payee.pa, pn: payee.name, cu: 'INR' });
  if (payee.amount) params.set('am', payee.amount);
  if (payee.note) params.set('tn', payee.note);
  return `upi://pay?${params.toString()}`;
}

function AppMark() {
  return (
    <span className="brand-mark" aria-hidden="true">
      <ShieldCheck />
    </span>
  );
}

function Topbar({ view, onBack }: { view: View; onBack: () => void }) {
  return (
    <header className="topbar">
      {view === 'home' ? (
        <div className="brand" data-testid="brand-verified-pay">
          <AppMark />
          <span className="brand-name">Verified</span>
          <span className="brand-meta">Card &amp; QR Pay</span>
        </div>
      ) : (
        <button className="back-button" onClick={onBack} data-testid="button-back-home">
          <ArrowLeft size={15} />
          Back to safety desk
        </button>
      )}
      <div className="status-stamp" data-testid="status-protection-active">
        <span className="signal-dot" />
        Protection active
      </div>
    </header>
  );
}

function Home({ onChoose }: { onChoose: (view: View) => void }) {
  return (
    <main className="content-wrap home-grid view-enter">
      <section className="hero" aria-labelledby="home-title">
        <div className="eyebrow"><span className="eyebrow-line" /> safety desk / ready</div>
        <h1 id="home-title">Pause before money <em>moves.</em></h1>
        <p className="hero-copy">
          A clear checkpoint for unusual activity. Verify where your card is, then verify who a QR payment is going to — before anything irreversible happens.
        </p>
        <div className="hero-note" data-testid="text-verification-disclosure">
          <Info size={15} />
          <span>Verification happens here. Your bank or UPI app still completes any transaction.</span>
        </div>
      </section>
      <section className="choice-panel" aria-label="Choose a safety action">
        <div className="choice-panel-inner">
          <div className="panel-kicker"><span>two deliberate checks</span><span className="signal-dot" /></div>
          <p className="choice-intro">What needs your attention?</p>
          <div className="choice-list">
            <button className="choice-button" onClick={() => onChoose('cards')} data-testid="button-card-controls">
              <span className="choice-icon"><CreditCard size={21} /></span>
              <span><h3>Card controls</h3><p>Lock cards and set a trusted location.</p></span>
              <ArrowRight className="choice-arrow" size={17} />
            </button>
            <button className="choice-button" onClick={() => onChoose('qr')} data-testid="button-pay-by-qr">
              <span className="choice-icon coral"><QrCode size={21} /></span>
              <span><h3>Pay by QR</h3><p>Match a UPI ID before opening your payment app.</p></span>
              <ArrowRight className="choice-arrow" size={17} />
            </button>
          </div>
          <div className="panel-footer"><ShieldCheck size={14} /><span>No money moves inside this safety desk.</span></div>
        </div>
      </section>
    </main>
  );
}

function SampleCard({ card }: { card: CardRecord }) {
  return (
    <div className={`sample-card ${card.id === 'travel' ? 'copper' : ''} ${card.locked ? 'is-locking' : ''}`} data-testid={`card-${card.id}`}>
      <div className="card-brand"><span>VERIFIED</span><span>VC</span></div>
      <div className="chip" aria-hidden="true" />
      <div className="card-number">•••• &nbsp; •••• &nbsp; •••• &nbsp; {card.lastFour}</div>
      <div className="card-bottom"><span>{card.name}</span><span>{card.type}</span></div>
      <div className={`card-state ${card.locked ? 'locked' : ''}`} data-testid={`status-card-${card.id}`}>
        <span className="state-dot" /> {card.locked ? 'Locked' : 'Ready to use'}
      </div>
    </div>
  );
}

function LocationPanel({
  location,
  onLocate,
  radius,
  onRadius,
  trusted,
  onTrusted,
  onRequestOtp,
  otpMessage,
}: {
  location: LocationState;
  onLocate: () => void;
  radius: number;
  onRadius: (value: number) => void;
  trusted: boolean;
  onTrusted: () => void;
  onRequestOtp: () => void;
  otpMessage: string;
}) {
  const locationIcon = location.status === 'error' || location.status === 'confirmation' ? <CircleAlert size={17} /> : <MapPin size={17} />;
  return (
    <aside className="surface surface-pad location-card" aria-label="Location controls">
      <div className="surface-title"><h2>Trusted location</h2><Crosshair size={17} color="hsl(var(--secondary))" /></div>
      <div className={`location-status ${location.status === 'error' || location.status === 'confirmation' ? 'error' : ''}`} data-testid="status-location">
        {locationIcon}
        <div><h3>{location.label}</h3><p>{location.detail}</p></div>
      </div>
      {location.status !== 'ready' && location.status !== 'confirmation' && (
        <button className="small-button" onClick={onLocate} disabled={location.status === 'loading'} data-testid="button-detect-location">
          <MapPin size={14} /> {location.status === 'loading' ? 'Requesting location…' : 'Use my location'}
        </button>
      )}
      <div className="range-wrap">
        <div className="range-head"><span>Safety radius</span><span className="range-value">{radius} km</span></div>
        <input type="range" min="1" max="25" step="1" value={radius} onChange={(event) => onRadius(Number(event.target.value))} aria-label="Safety radius in kilometres" data-testid="input-location-radius" />
      </div>
      <div className="switch-line">
        <div className="switch-copy"><h3>Trust this area</h3><p>Keep cards available within the radius.</p></div>
        <button className={`switch ${trusted ? 'on' : ''}`} onClick={onTrusted} role="switch" aria-checked={trusted} aria-label="Toggle trusted area" data-testid="button-toggle-trusted-area"><span className="switch-thumb" /></button>
      </div>
      {location.status === 'confirmation' && location.challengeId && (
        <div className="location-challenge" data-testid="location-confirmation">
          <div className="challenge-title"><Landmark size={15} /> Bank confirmation required</div>
          <p>The browser detected a move outside the trusted radius. Request an SMS OTP before card use continues.</p>
          <button className="small-button action-button coral" onClick={onRequestOtp} data-testid="button-request-location-otp">
            <Smartphone size={14} /> Request SMS OTP
          </button>
          {otpMessage && <div className="validation bad" data-testid="status-otp-provider"><CircleAlert size={13} /> {otpMessage}</div>}
        </div>
      )}
      <div className="notice"><ShieldCheck size={15} /><span>Location is a safety signal, not a guarantee. Keep your usual checks on.</span></div>
    </aside>
  );
}

function CardsView() {
  const queryClient = useQueryClient();
  const { data: savedCards, isLoading: cardsLoading } = useListCards();
  const [lockedIds, setLockedIds] = useState<string[]>([]);
  const [radius, setRadius] = useState(5);
  const [trusted, setTrusted] = useState(false);
  const [location, setLocation] = useState<LocationState>({ status: 'idle', label: 'Location not checked', detail: 'Use your browser location to compare against the last known place.' });
  const [cardMessage, setCardMessage] = useState('');
  const [otpMessage, setOtpMessage] = useState('');
  const completedSetupRef = useRef<string | null>(null);
  const setupCard = useCreateCardSetupSession({
    mutation: {
      onSuccess: (result) => window.location.assign(result.url),
      onError: () => setCardMessage('The secure card setup page could not be opened. Please try again.'),
    },
  });
  const completeCardSetup = useCompleteCardSetupSession({
    mutation: {
      onSuccess: () => {
        setCardMessage('Card verified and saved as a tokenized payment method.');
        void queryClient.invalidateQueries({ queryKey: getListCardsQueryKey() });
      },
      onError: () => setCardMessage('Stripe did not verify the card setup. No card credentials were saved.'),
    },
  });
  const checkLocation = useCheckLocation({
    mutation: {
      onSuccess: (result) => {
        if (result.status === 'requires_confirmation') {
          setLocation({
            status: 'confirmation',
            label: 'Move detected',
            detail: `${result.distanceKm?.toFixed(1) ?? 'Unknown'} km from the last known place · confirmation required`,
            challengeId: result.challengeId,
          });
          setTrusted(false);
          setOtpMessage('');
        } else {
          setLocation({
            status: 'ready',
            label: result.status === 'baseline' ? 'Starting location saved' : 'Location within trusted radius',
            detail: result.message,
            challengeId: null,
          });
        }
      },
      onError: () => setLocation({ status: 'error', label: 'Location check failed', detail: 'The server could not record this location. Please retry.' }),
    },
  });
  const requestOtp = useRequestLocationOtp({
    mutation: {
      onSuccess: (result) => setOtpMessage(result.message),
      onError: (error) => {
        const data = (error as { data?: { message?: string } }).data;
        setOtpMessage(data?.message || 'No OTP was sent. The SMS provider is not connected.');
      },
    },
  });

  const cards: CardRecord[] = (savedCards || []).map((card) => ({
    id: card.id,
    name: card.cardholderName || `${card.brand.toUpperCase()} card`,
    lastFour: card.last4,
    type: `${card.brand.toUpperCase()} CARD`,
    locked: lockedIds.includes(card.id),
    expMonth: card.expMonth,
    expYear: card.expYear,
  }));

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const setupSessionId = params.get('session_id');
    if (params.get('card_setup') !== 'success' || !setupSessionId || completedSetupRef.current === setupSessionId) return;
    completedSetupRef.current = setupSessionId;
    completeCardSetup.mutate({ data: { sessionId: setupSessionId } });
    window.history.replaceState({}, '', window.location.pathname);
  }, [completeCardSetup]);

  const detectLocation = () => {
    if (!navigator.geolocation) {
      setLocation({ status: 'error', label: 'Location unavailable', detail: 'This browser does not provide location access. You can still lock cards manually.' });
      return;
    }
    setLocation({ status: 'loading', label: 'Checking your location…', detail: 'Your browser will ask for permission.' });
    navigator.geolocation.getCurrentPosition(
      (position) => {
        checkLocation.mutate({
          data: {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracyMeters: Math.round(position.coords.accuracy),
            trustedRadiusKm: radius,
          },
        });
      },
      (error) => {
        const detail = error.code === 1 ? 'Permission was not granted. You can retry or manage it in browser settings.' : 'We could not get a reliable position. Please retry.';
        setLocation({ status: 'error', label: 'Location not found', detail });
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 },
    );
  };
  const toggleCard = (id: string) => setLockedIds((current) => current.includes(id) ? current.filter((value) => value !== id) : [...current, id]);

  return (
    <main className="content-wrap view-enter">
      <div className="view-header">
        <div className="view-title">
          <div className="eyebrow"><span className="eyebrow-line" /> card controls / manual check</div>
          <h1>Your cards, on your terms.</h1>
          <p>Add a card through Stripe&apos;s hosted setup page. Only a tokenized reference and masked metadata return to this system; full card credentials never enter this app.</p>
        </div>
        <button className="small-button action-button primary" onClick={() => setupCard.mutate()} disabled={setupCard.isPending} data-testid="button-add-card">
          <CreditCard size={14} /> {setupCard.isPending ? 'Opening secure setup…' : 'Add a new card'}
        </button>
      </div>
      {cardMessage && <div className="inline-message" data-testid="status-card-setup"><ShieldCheck size={15} /> {cardMessage}</div>}
      <div className="cards-layout">
        <section className="surface surface-pad">
          <div className="surface-title"><h2>Card wallet</h2><span className="mono-label">{cards.length} saved token{cards.length === 1 ? '' : 's'}</span></div>
          {cardsLoading && <div className="result-empty compact"><div><div className="empty-mark"><CreditCard size={25} /></div><h3>Loading saved cards</h3><p>Reading tokenized card summaries from the secure system.</p></div></div>}
          {!cardsLoading && cards.length === 0 && <div className="result-empty compact"><div><div className="empty-mark"><CreditCard size={25} /></div><h3>No cards saved yet</h3><p>Add a card through Stripe to create the first tokenized record.</p></div></div>}
          {cards.length > 0 && <div className="cards-stack">{cards.map((card) => <SampleCard key={card.id} card={card} />)}</div>}
          {cards.length > 0 && <div className="card-control-list">
            {cards.map((card) => (
              <div className="control-row" key={card.id}>
                <div className="control-copy"><h3>{card.name} ···· {card.lastFour}</h3><p>{card.locked ? 'New payments are paused in this interface.' : 'Tokenized card is available for the next bank-controlled action.'}</p></div>
                <button className={`small-button ${card.locked ? 'action-button coral' : ''}`} onClick={() => toggleCard(card.id)} data-testid={`button-toggle-card-${card.id}`}>
                  {card.locked ? <><Unlock size={14} /> Unlock</> : <><Lock size={14} /> Lock card</>}
                </button>
              </div>
            ))}
          </div>}
          <div className="notice"><Info size={15} /><span>Stripe stores the sensitive card credentials. This system stores only the provider token, last four digits, brand, and expiry.</span></div>
        </section>
        <LocationPanel
          location={location}
          onLocate={detectLocation}
          radius={radius}
          onRadius={setRadius}
          trusted={trusted}
          onTrusted={() => setTrusted((value) => !value)}
          onRequestOtp={() => location.challengeId && requestOtp.mutate({ challengeId: location.challengeId })}
          otpMessage={otpMessage}
        />
      </div>
      <div className="footer-line">Tokenized cards · location checks recorded · bank confirmation is blocked until an SMS provider is connected</div>
    </main>
  );
}

function QrView() {
  const [upiId, setUpiId] = useState('');
  const [payee, setPayee] = useState<Payee | null>(null);
  const [scanState, setScanState] = useState<'empty' | 'scanning' | 'good' | 'bad'>('empty');
  const [scanMessage, setScanMessage] = useState('A QR payee will appear here after a scan.');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const match = Boolean(payee && upiId.trim() === payee.pa.trim());
  const exactInput = upiId.trim().length > 0;

  const handlePayload = (payload: string) => {
    const decoded = parseUpiPayload(payload);
    if (!decoded) {
      setPayee(null);
      setScanState('bad');
      setScanMessage('Not found / Mismatch — this is not a readable UPI payment QR.');
      return;
    }
    setPayee(decoded);
    setScanState('good');
    setScanMessage('UPI payee decoded. Compare it with the ID you entered.');
  };

  const decodeWithBrowser = async (source: HTMLImageElement | HTMLVideoElement) => {
    const Detector = (window as unknown as { BarcodeDetector?: new (options?: { formats: string[] }) => { detect: (item: HTMLImageElement | HTMLVideoElement) => Promise<Array<{ rawValue?: string }>> } }).BarcodeDetector;
    if (!Detector) {
      setScanState('bad');
      setScanMessage('Not found / Mismatch — this browser does not support QR reading. Try a browser with BarcodeDetector.');
      return;
    }
    try {
      const detector = new Detector({ formats: ['qr_code'] });
      const codes = await detector.detect(source);
      if (!codes[0]?.rawValue) {
        setScanState('bad');
        setScanMessage('Not found / Mismatch — no readable UPI QR was found.');
        return;
      }
      handlePayload(codes[0].rawValue);
    } catch {
      setScanState('bad');
      setScanMessage('Not found / Mismatch — the QR could not be read. Try a sharper image.');
    }
  };

  const handleFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setScanState('scanning');
    setScanMessage('Reading QR image…');
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => { void decodeWithBrowser(image); };
      image.onerror = () => {
        setScanState('bad');
        setScanMessage('Not found / Mismatch — this file is not a readable image.');
      };
      image.src = String(reader.result);
    };
    reader.onerror = () => {
      setScanState('bad');
      setScanMessage('Not found / Mismatch — the image could not be opened.');
    };
    reader.readAsDataURL(file);
  };

  const startCamera = async () => {
    setCameraError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('Camera access is not available in this browser.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      setCameraStream(stream);
      setCameraOpen(true);
      setScanState('scanning');
      setScanMessage('Camera ready. Place the QR inside the frame.');
    } catch {
      setCameraError('Camera permission was not granted. You can upload a QR image instead.');
    }
  };

  const stopCamera = () => {
    cameraStream?.getTracks().forEach((track) => track.stop());
    setCameraStream(null);
    setCameraOpen(false);
    if (scanState === 'scanning') {
      setScanState('empty');
      setScanMessage('A QR payee will appear here after a scan.');
    }
  };

  useEffect(() => {
    if (cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
      void videoRef.current.play();
    }
  }, [cameraStream]);

  useEffect(() => {
    if (!cameraOpen || !cameraStream || !videoRef.current) return;
    const interval = window.setInterval(() => {
      if (videoRef.current?.readyState === 4) void decodeWithBrowser(videoRef.current);
    }, 850);
    return () => window.clearInterval(interval);
  });

  useEffect(() => () => {
    cameraStream?.getTracks().forEach((track) => track.stop());
  }, [cameraStream]);

  const reset = () => {
    stopCamera();
    setUpiId('');
    setPayee(null);
    setScanState('empty');
    setScanMessage('A QR payee will appear here after a scan.');
    setCameraError('');
  };

  const executePayment = () => {
    if (!match || !payee) return;
    window.location.assign(buildPaymentLink(payee));
  };

  return (
    <main className="content-wrap view-enter">
      <div className="view-header">
        <div className="view-title">
          <div className="eyebrow"><span className="eyebrow-line" /> QR pay / two-key check</div>
          <h1>Know who gets paid.</h1>
          <p>Enter the UPI ID yourself, then scan the QR. Payment only becomes available when both IDs match exactly.</p>
        </div>
        <button className="text-button" onClick={reset} data-testid="button-reset-qr"><X size={14} /> Reset check</button>
      </div>
      <div className="qr-layout">
        <section className="surface surface-pad" aria-label="QR payment verification">
          <div className="qr-step">
            <span className="step-number">01</span>
            <div className="step-body">
              <h2>Type the payee&apos;s UPI ID</h2>
              <p>Use the ID you were given, not one copied from an untrusted message.</p>
              <div className="input-wrap">
                <input className="text-input" value={upiId} onChange={(event) => setUpiId(event.target.value)} placeholder="name@bank" aria-label="Payee UPI ID" autoComplete="off" data-testid="input-upi-id" />
              </div>
              {exactInput && !/^[a-z0-9][a-z0-9._-]{1,254}@[a-z][a-z0-9.-]{1,63}$/i.test(upiId.trim()) && (
                <div className="validation bad" data-testid="status-upi-format"><CircleAlert size={13} /> This does not look like a valid UPI ID.</div>
              )}
            </div>
          </div>
          <div className="qr-step">
            <span className="step-number">02</span>
            <div className="step-body">
              <h2>Scan the payment QR</h2>
              <p>Use an image or your camera. The browser reads the QR locally when supported.</p>
              <div className="scan-options">
                <label className="small-button scan-button upload-label" data-testid="button-upload-qr">
                  <Upload size={17} /><span>Upload QR image</span>
                  <input type="file" accept="image/*" onChange={handleFile} aria-label="Upload QR image" />
                </label>
                <button className="small-button scan-button" onClick={cameraOpen ? stopCamera : startCamera} data-testid="button-camera-scan">
                  <Camera size={17} /><span>{cameraOpen ? 'Stop camera' : 'Use camera'}</span>
                </button>
              </div>
              {cameraError && <div className="validation bad" data-testid="status-camera-error"><CircleAlert size={13} /> {cameraError}</div>}
              {cameraOpen && <div className="camera-box" data-testid="camera-preview"><video ref={videoRef} muted playsInline /><div className="camera-guide" /><span className="camera-note">Searching for a QR code</span></div>}
            </div>
          </div>
          <div className="notice"><ShieldCheck size={15} /><span>We verify the payee here. Selecting Pay opens your UPI app, where you review and authorize the transaction.</span></div>
        </section>
        <section className="surface qr-result" aria-label="Decoded payee result">
          <div className="surface-pad surface-title"><h2>Verification result</h2><span className="mono-label">{scanState === 'good' ? 'decoded' : 'waiting'}</span></div>
          {scanState === 'empty' && <div className="result-empty" data-testid="state-qr-empty"><div><div className="empty-mark"><ScanLine size={25} /></div><h3>Waiting for a QR</h3><p>{scanMessage}</p></div></div>}
          {scanState === 'scanning' && <div className="result-empty" data-testid="state-qr-loading"><div><div className="empty-mark"><QrCode size={25} /></div><h3>Reading carefully</h3><p>{scanMessage}</p></div></div>}
          {scanState === 'bad' && <div className="result-content" data-testid="state-qr-mismatch"><div className="match-banner bad"><CircleAlert size={18} /><div><strong>Not found / Mismatch</strong><span>{scanMessage}</span></div></div><button className="small-button" style={{ marginTop: 19 }} onClick={reset} data-testid="button-retry-qr"><ScanLine size={14} /> Try another QR</button></div>}
          {scanState === 'good' && payee && (
            <div className="result-content" data-testid="state-qr-decoded">
              <div className={`match-banner ${match ? '' : 'bad'}`}>
                {match ? <Check size={18} /> : <CircleAlert size={18} />}
                <div><strong>{match ? 'Verified match' : 'Not found / Mismatch'}</strong><span>{match ? 'The entered UPI ID and QR payee are the same.' : 'The entered UPI ID does not match this QR payee. Payment stays disabled.'}</span></div>
              </div>
              <div className="payee-details">
                <span className="mono-label">QR payee details</span>
                <div className="detail-row"><span>UPI ID</span><span data-testid="text-decoded-upi">{payee.pa}</span></div>
                <div className="detail-row"><span>Name</span><span data-testid="text-decoded-name">{payee.name}</span></div>
                {payee.amount && <div className="detail-row"><span>Amount</span><span data-testid="text-decoded-amount">₹{payee.amount}</span></div>}
                {payee.note && <div className="detail-row"><span>Note</span><span>{payee.note}</span></div>}
              </div>
              <div className="result-actions">
                <button className="action-button primary" disabled={!match} onClick={executePayment} data-testid="button-open-upi"><Smartphone size={15} /> {match ? 'Open UPI app' : 'Match required'}</button>
                <button className="small-button" onClick={reset} data-testid="button-reset-result">Reset</button>
              </div>
              <div className="notice"><Landmark size={15} /><span>No transaction success is shown here. Your UPI app completes the payment and shows its own result.</span></div>
            </div>
          )}
        </section>
      </div>
      <div className="footer-line">UPI verification · local browser reading · no payment history stored</div>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function HomePage() {
  const [view, setView] = useState<View>('home');
  return (
    <div className="app-shell">
      <Topbar view={view} onBack={() => setView('home')} />
      {view === 'home' && <Home onChoose={setView} />}
      {view === 'cards' && <CardsView />}
      {view === 'qr' && <QrView />}
    </div>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;