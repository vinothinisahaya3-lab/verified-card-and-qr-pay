import {
  integer,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const userSessions = pgTable("verified_user_sessions", {
  id: text("id").primaryKey(),
  stripeCustomerId: text("stripe_customer_id"),
  phoneE164: text("phone_e164"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const cardProfiles = pgTable(
  "verified_card_profiles",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id").notNull(),
    stripeCustomerId: text("stripe_customer_id").notNull(),
    stripePaymentMethodId: text("stripe_payment_method_id").notNull(),
    brand: text("brand").notNull(),
    last4: text("last4").notNull(),
    expMonth: integer("exp_month").notNull(),
    expYear: integer("exp_year").notNull(),
    cardholderName: text("cardholder_name"),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    paymentMethodUnique: uniqueIndex("verified_card_payment_method_unique").on(
      table.stripePaymentMethodId,
    ),
  }),
);

export const locationEvents = pgTable("verified_location_events", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  accuracyMeters: integer("accuracy_meters"),
  previousLatitude: real("previous_latitude"),
  previousLongitude: real("previous_longitude"),
  distanceKm: real("distance_km"),
  status: text("status").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const locationChallenges = pgTable("verified_location_challenges", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  locationEventId: text("location_event_id").notNull(),
  status: text("status").notNull().default("pending"),
  channel: text("channel").notNull().default("sms"),
  maskedDestination: text("masked_destination"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});